---
name: Academic Precision
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#404751'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#707883'
  outline-variant: '#bfc7d3'
  surface-tint: '#0062a0'
  primary: '#0062a0'
  on-primary: '#ffffff'
  primary-container: '#49aaff'
  on-primary-container: '#003d66'
  inverse-primary: '#9ccaff'
  secondary: '#2f628d'
  on-secondary: '#ffffff'
  secondary-container: '#9eceff'
  on-secondary-container: '#235882'
  tertiary: '#4c6171'
  on-tertiary: '#ffffff'
  tertiary-container: '#92a7ba'
  on-tertiary-container: '#283d4c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d0e4ff'
  primary-fixed-dim: '#9ccaff'
  on-primary-fixed: '#001d35'
  on-primary-fixed-variant: '#00497a'
  secondary-fixed: '#cfe5ff'
  secondary-fixed-dim: '#9bcbfc'
  on-secondary-fixed: '#001d33'
  on-secondary-fixed-variant: '#0e4a74'
  tertiary-fixed: '#cfe5f9'
  tertiary-fixed-dim: '#b3c9dd'
  on-tertiary-fixed: '#061e2c'
  on-tertiary-fixed-variant: '#344959'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: 0em
  title-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
  data-mono:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system reflects an institutional SaaS ecosystem tailored for modern academic operations, timetable choreography, and campus asset planning. It balances administrative gravitas with fluid consumer-grade ergonomics, catering to department chairs, registrars, faculty, and students who require cognitive clarity under high data density.

The visual direction follows **Corporate / Modern Minimalism** with architectural precision. Interfaces maintain generous breathability, structural alignment, and strict functional utility. Extraneous decoration is eliminated in favor of pristine typography, restrained chromatic accents, crisp micro-interactions, and systematic status codification. The atmosphere is confident, reliable, orderly, and calm.

## Colors
The palette balances institutional authority with high-visibility interaction cues and low-fatigue structural neutrals.

### Core Swatches
- **Primary Accent (`#49AAFF`)**: Primary action triggers, selected calendar events, active focus rings, and high-priority interactive highlights.
- **Secondary / Brand Navy (`#2D608B`)**: Structural headers, primary navigation sidebars, major column titles, and foundational brand anchoring.
- **Tertiary Tint (`#D2E8FC`)**: Hover states, active row selections, light surface fills, and time-block container backgrounds.
- **Text & Deep Accents (`#101010`)**: High-contrast body copy, sharp headline text, icons, and precise data readouts.
- **Structural Neutral (`#D4D4D8`)**: Subdued hair-line dividers, calendar cell grids, card borders, and disabled controls.
- **Canvas Base (`#FFFFFF` & `#F8FAFC`)**: Layered base surfaces; `#F8FAFC` anchors application canvases and control rails, while `#FFFFFF` elevates active cards, modals, and schedule views.

### Academic & Status Taxonomy
- **Theory**: Ink Navy background (`#EDF4FA`), text & border `#2D608B`.
- **Lab**: Cobalt Cyan background (`#EBF5FF`), text & border `#1A7DD7`.
- **Tutorial**: Indigo slate background (`#EEF2F6`), text & border `#3E5C76`.
- **Project**: Cerulean background (`#E0F2FE`), text & border `#0369A1`.
- **Pending**: Neutral amber background (`#FEF3C7`), text & border `#B45309`.
- **Action Required**: Crimson wash background (`#FEE2E2`), text & border `#B91C1C`.
- **Approved / Completed**: Forest teal background (`#DCFCE7`), text & border `#15803D`.

## Typography
Typographic rhythm relies on `Inter` across all structural layers to maximize legibility across complex multi-column matrices, schedules, and dashboard feeds.

- **Tabular Figures**: Timetable clocks, room codes, credit counts, and dates must enforce `font-feature-settings: "tnum" 1, "cv05" 1, "cv11" 1` to guarantee absolute vertical baseline alignment in dense schedules.
- **Hierarchy Hierarchy**: Titles and headings apply subtle negative tracking (`-0.01em` to `-0.025em`) to preserve visual density. Labels and status chips utilize medium weights (`500`) with neutral tracking for immediate scanability.
- **Contrast Ratios**: Body text utilizes `#101010` on white and slate surfaces, exceeding WCAG AAA standards. Secondary text uses a subdued tint derived from the deep palette (`#52525B`) to maintain strict optical stratification.

## Layout & Spacing
The layout employs an asymmetric, fluid application frame anchored by a fixed left navigation sidebar and a top-fixed operational bar.

### Grid & Breakpoints
- **Mobile (< 768px)**: 4-column layout, `1rem` margin, collapsing the primary sidebar into an off-canvas drawer and converting timetables into vertical agenda ribbons.
- **Tablet (768px - 1024px)**: 8-column layout, `1.25rem` margin and gutters, with a slim, icon-only navigation rail (`64px` width).
- **Desktop (> 1024px)**: 12-column layout, `2rem` margin, `1.5rem` gutter. The main work area expands fluidly while maintaining a fixed left sidebar (`260px`). Timetable grids apply equal 5-day or 7-day programmatic column splits with independent vertical scroll containers.

### Spacing Philosophy
All inner component paddings and gaps align strictly with an 8pt base grid (`0.25rem` intervals). Dense timetable cells utilize `space-xs` and `space-sm` for compact internal padding, while macro layout containers leverage `space-lg` and `space-xl` to prevent cognitive fatigue.

## Elevation & Depth
Depth is constructed through **tonal layering and low-contrast outlines** rather than heavy blurred drop shadows. This preserves a lightweight, architectural aesthetic that avoids cluttering grid-heavy scheduling views.

- **Level 0 (Canvas Base)**: `#F8FAFC` background for overall application structural frames and navigation backing.
- **Level 1 (Surface Containers & Cards)**: `#FFFFFF` background bound by a crisp `1px` border of `#D4D4D8`. No ambient shadow is applied in resting states.
- **Level 2 (Interactive Floating / Dropdowns)**: Fills with `#FFFFFF`, bordered by `1px solid #D4D4D8`, supported by an ultra-subtle ambient shadow: `0 4px 12px -2px rgba(16, 16, 16, 0.04), 0 2px 6px -1px rgba(16, 16, 16, 0.02)`.
- **Level 3 (Modals & Overlays)**: `#FFFFFF` surfaced modals atop a semi-transparent slate wash backdrop (`rgba(16, 16, 16, 0.35)` with `backdrop-filter: blur(4px)`). Elevated with a soft perimeter shadow: `0 20px 25px -5px rgba(16, 16, 16, 0.08), 0 8px 10px -6px rgba(16, 16, 16, 0.04)`.

## Shapes
A roundedness tier of `2` provides modern softness while honoring the clean, structural requirements of timetable data tables.

- **Base Radius (`0.5rem` / `8px`)**: Applied to interactive form fields, dropdown items, standard action buttons, and individual schedule course blocks.
- **Card & Modal Radius (`rounded-lg` / `1rem` / `16px`)**: Applied to all primary administrative panels, course detail slide-overs, and timetable workspace canvases.
- **Pill Elements (`9999px`)**: Reserved exclusively for atomic tags, category chips (Theory, Lab, etc.), and operational status badges to distinctly separate them from interactive inputs and block-level calendar cards.

## Components

### Buttons
- **Primary**: Solid background `#49AAFF`, text `#101010`, font weight `600`, radius `0.5rem`. Hover shifts to `#3B93DE` with seamless transition. Focus ring is an offset `2px solid #2D608B`.
- **Secondary**: Surface `#FFFFFF`, border `1px solid #D4D4D8`, text `#101010`. Hover transitions to background `#F8FAFC` with border `#2D608B`.
- **Tertiary / Ghost**: Transparent fill, text `#2D608B`, hover background `#D2E8FC` with `25%` opacity.

### Navigation Sidebar & Top Search Bar
- **Sidebar**: Grounded in `#F8FAFC` (or crisp `#FFFFFF` separated by `1px solid #D4D4D8`). Navigation links use minimal outline icons, `14px` labels, and state changes indicated by `#D2E8FC` background pills with `#2D608B` typography and a active left accent indicator.
- **Top Search Bar**: Global search positioned centrally with an omnipresent shortcut indicator (`⌘K`). Surface `#FFFFFF` encased in `1px solid #D4D4D8`, containing an outline magnifying glass and placeholder text in `#71717A`.

### Status Badges & Academic Category Chips
- **Chips**: Compact height (`24px`), horizontal padding `8px`, rounded-pill (`9999px`), uppercase `11px` tracking with `600` weight.
- **Classification Badges**: Course taxonomy (Theory, Lab, Tutorial, Project) uses subtle tinted backgrounds with high-contrast text and border treatments as specified in the color architecture.
- **Lifecycle Badges**: Status indicators (Pending, Action Required, Approved, Completed) include a leading `6px` solid status dot preceding the label.

### Cards & Timetable Time-Blocks
- **Administrative Cards**: Surfaced in `#FFFFFF`, bordered with `1px solid #D4D4D8`, padding `1.5rem`, corner radius `1rem`.
- **Calendar Event Blocks**: Absolute or flex child cards inside timetable lanes. Styled with background `#FFFFFF`, left accent border (`4px solid #49AAFF` or category equivalent), perimeter border `1px solid #D4D4D8`, and subtle hover transform (`translateY(-1px)`).

### Input Fields & Controls
- **Inputs**: Height `40px`, background `#FFFFFF`, border `1px solid #D4D4D8`, radius `0.5rem`, padding `0 12px`. Focus state triggers border `#49AAFF` with an immediate `0 0 0 3px rgba(73, 170, 255, 0.25)` outline.
- **Checkboxes & Radios**: Border `1.5px solid #D4D4D8`, active fill `#49AAFF` with white checkmark. Checked focus creates a soft halo using `#D2E8FC`.